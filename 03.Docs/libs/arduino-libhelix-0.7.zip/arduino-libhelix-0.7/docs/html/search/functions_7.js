var searchData=
[
  ['setmaxframesize_34',['setMaxFrameSize',['../classlibhelix_1_1_common_helix.html#a28a81c90298d1dbc107b2b799ce3fed2',1,'libhelix::CommonHelix']]],
  ['setmaxpwmsize_35',['setMaxPWMSize',['../classlibhelix_1_1_common_helix.html#a822ababebd5f0d6ffe29e1c43b722772',1,'libhelix::CommonHelix']]],
  ['synchronizeframe_36',['synchronizeFrame',['../classlibhelix_1_1_common_helix.html#a33ae215e20b7ece5cadf1a0b7098aff9',1,'libhelix::CommonHelix']]]
];
