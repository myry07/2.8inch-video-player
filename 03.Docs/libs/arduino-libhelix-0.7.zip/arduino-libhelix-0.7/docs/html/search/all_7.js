var searchData=
[
  ['maxframesize_10',['maxFrameSize',['../classlibhelix_1_1_a_a_c_decoder_helix.html#a43de4d6db7ea26af9ececfb89f7901e3',1,'libhelix::AACDecoderHelix::maxFrameSize()'],['../classlibhelix_1_1_common_helix.html#a5b0fff8a3e335fe2ae5d7e2ed744cc15',1,'libhelix::CommonHelix::maxFrameSize()'],['../classlibhelix_1_1_m_p3_decoder_helix.html#a8b0a6d37f62728a476096f3d8f3f36a0',1,'libhelix::MP3DecoderHelix::maxFrameSize()']]],
  ['maxpwmsize_11',['maxPWMSize',['../classlibhelix_1_1_a_a_c_decoder_helix.html#a084e2cbfab5d352b302a053a39baeacf',1,'libhelix::AACDecoderHelix::maxPWMSize()'],['../classlibhelix_1_1_common_helix.html#af2ad233fe8e092b474676b77f1bffd2a',1,'libhelix::CommonHelix::maxPWMSize()'],['../classlibhelix_1_1_m_p3_decoder_helix.html#a96d1311e201d4a63fd2d78fceab0bbff',1,'libhelix::MP3DecoderHelix::maxPWMSize()']]],
  ['mp3decoderhelix_12',['MP3DecoderHelix',['../classlibhelix_1_1_m_p3_decoder_helix.html',1,'libhelix']]]
];
