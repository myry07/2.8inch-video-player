var searchData=
[
  ['appendtobuffer_24',['appendToBuffer',['../classlibhelix_1_1_common_helix.html#a0ffba0347a7739d3c8bd3fd270116525',1,'libhelix::CommonHelix']]],
  ['audioinfo_25',['audioInfo',['../classlibhelix_1_1_a_a_c_decoder_helix.html#a25c720a79d70bf35da7405442686512d',1,'libhelix::AACDecoderHelix::audioInfo()'],['../classlibhelix_1_1_m_p3_decoder_helix.html#a5d2e73af46a007b7f672595baa9e36a6',1,'libhelix::MP3DecoderHelix::audioInfo()']]]
];
